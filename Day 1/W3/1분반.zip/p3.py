Grade = input("Enter a letter grade: ")
print(Grade in ('A', 'B', 'C', 'D', 'F', 'a', 'b', 'c', 'd', 'f'))

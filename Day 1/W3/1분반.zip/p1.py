INT = int(input("Enter an integer: "))

print( (-2 <= INT) and (INT <=3) and (INT!=0))
